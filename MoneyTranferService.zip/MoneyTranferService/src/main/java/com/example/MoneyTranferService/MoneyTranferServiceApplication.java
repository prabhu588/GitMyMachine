package com.example.MoneyTranferService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoneyTranferServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoneyTranferServiceApplication.class, args);
	}

}
